/*jslint node: true */
'use strict';

var server = require('./server');
server.start({ port: 3000 });