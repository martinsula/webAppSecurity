angular.module('myApp').controller('AboutController', [
    function () {
        'use strict';

    }]);