angular.module('myApp').controller('AdministrationController', [
    function () {
        'use strict';

    }]);