angular.module('myApp').controller('NavbarController', [
    function () {
        'use strict';

    }]);