/*jslint node: true */
var grunt = require('grunt');

grunt.tasks(['minify']);